import Link from "next/link"
import { ArrowLeft, CreditCard } from "lucide-react"

export default function Payment() {
  return (
    <div className="min-h-screen bg-[#faf8ff] p-8">
      <div className="max-w-md mx-auto">
        <Link href="/" className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-8">
          <ArrowLeft className="mr-2" size={20} />
          Back to Vision Board
        </Link>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h1 className="text-2xl font-bold mb-6">Complete Your Purchase</h1>

          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Order Summary</h2>
            <div className="flex justify-between py-3 border-b">
              <span>Vision Board Download</span>
              <span className="font-semibold">$27.00</span>
            </div>
            <div className="flex justify-between py-3">
              <span className="font-semibold">Total</span>
              <span className="font-semibold">$27.00</span>
            </div>
          </div>

          <button className="w-full bg-black text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors">
            <CreditCard size={20} />
            Pay $27.00
          </button>

          <p className="text-sm text-gray-500 text-center mt-4">
            Secure payment processing. You will receive your download link immediately after payment.
          </p>
        </div>
      </div>
    </div>
  )
}

