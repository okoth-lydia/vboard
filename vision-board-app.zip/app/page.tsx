import dynamic from "next/dynamic"

const VisionBoard = dynamic(() => import("../components/VisionBoard"), { ssr: false })

export default function Home() {
  return <VisionBoard />
}

