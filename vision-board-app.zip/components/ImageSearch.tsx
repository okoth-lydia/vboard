"use client"

import { useState, useEffect } from "react"
import { Search } from "lucide-react"

const UNSPLASH_ACCESS_KEY = "4D3KZjIEcEIQl0V_mmsWD5NdcAoermMks8waT8adfa4"

export default function ImageSearch({ onImageSelect }: { onImageSelect: (imageUrl: string) => void }) {
  const [query, setQuery] = useState("")
  const [images, setImages] = useState<any[]>([])

  useEffect(() => {
    fetchInspirationalImages()
  }, [])

  const fetchInspirationalImages = async () => {
    const queries = ["success motivation", "business goals", "inspiration nature", "achievement"]
    const allImages = []

    for (const query of queries) {
      const response = await fetch(
        `https://api.unsplash.com/search/photos?query=${query}&client_id=${UNSPLASH_ACCESS_KEY}&per_page=3`,
      )
      const data = await response.json()
      allImages.push(...data.results)
    }

    setImages(allImages)
  }

  const searchImages = async () => {
    if (!query.trim()) return

    const response = await fetch(
      `https://api.unsplash.com/search/photos?query=${query}&client_id=${UNSPLASH_ACCESS_KEY}&per_page=12`,
    )
    const data = await response.json()
    setImages(data.results)
  }

  return (
    <div>
      <div className="flex gap-2 mb-6">
        <div className="relative flex-1">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && searchImages()}
            placeholder="Search for images..."
            className="w-full px-4 py-2 pr-10 border rounded-lg"
          />
          <button
            onClick={searchImages}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            <Search size={20} />
          </button>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {images.map((image) => (
          <div
            key={image.id}
            className="aspect-square cursor-move overflow-hidden rounded-lg"
            draggable="true"
            onDragStart={(e) => {
              e.dataTransfer.setData("text/plain", image.urls.regular)
            }}
          >
            <img
              src={image.urls.small || "/placeholder.svg"}
              alt={image.alt_description}
              className="w-full h-full object-cover hover:scale-110 transition-transform duration-200"
            />
          </div>
        ))}
      </div>
    </div>
  )
}

