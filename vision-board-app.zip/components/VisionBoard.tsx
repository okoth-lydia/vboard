"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Download } from "lucide-react"
import ImageSearch from "./ImageSearch"
import html2canvas from "html2canvas"

type BoardItem = {
  id: string
  content: string
  position: number
}

export default function VisionBoard() {
  const [items, setItems] = useState<BoardItem[]>([])
  const boardRef = useRef<HTMLDivElement>(null)

  const handleDrop = (e: React.DragEvent, position: number) => {
    e.preventDefault()
    const imageUrl = e.dataTransfer.getData("text/plain")

    // Check if there's already an image in this position
    const existingItem = items.find((item) => item.position === position)
    if (existingItem) return

    setItems([
      ...items,
      {
        id: Date.now().toString(),
        content: imageUrl,
        position,
      },
    ])
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const downloadBoard = async () => {
    if (boardRef.current) {
      const canvas = await html2canvas(boardRef.current)
      const image = canvas.toDataURL("image/png")
      const link = document.createElement("a")
      link.href = image
      link.download = "vision-board.png"
      link.click()
    }
  }

  return (
    <div className="flex min-h-screen bg-[#faf8ff]">
      <div className="flex-1 p-8">
        <h1 className="text-2xl font-bold mb-6">Your Vision Board</h1>
        <div ref={boardRef} className="grid grid-cols-3 gap-4 mb-6">
          {[...Array(9)].map((_, index) => (
            <div
              key={index}
              className={`aspect-square rounded-lg flex items-center justify-center text-gray-400 border-2 border-dashed border-gray-200 relative overflow-hidden
                ${items.some((item) => item.position === index) ? "bg-white" : "bg-[#e8f4f4]"}`}
              onDrop={(e) => handleDrop(e, index)}
              onDragOver={handleDragOver}
            >
              {items.find((item) => item.position === index) ? (
                <img
                  src={items.find((item) => item.position === index)?.content || "/placeholder.svg"}
                  alt="Vision board item"
                  className="w-full h-full object-cover"
                />
              ) : (
                "Drop image here"
              )}
            </div>
          ))}
        </div>
        <button
          onClick={downloadBoard}
          className="w-full bg-black text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors"
        >
          <Download size={20} />
          Download Board
        </button>
      </div>
      <div className="w-[600px] p-8 border-l">
        <ImageSearch onImageSelect={() => {}} />
      </div>
    </div>
  )
}

